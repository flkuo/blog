---
layout: post
category: surveillance
tagline: 
tags: [Surveillance]
---
{% include JB/setup %}

This page contains a collection of links of CDCs worldwide or national health-related/surveillance data.


* [USA] [USA CDC](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwj4kd7rwYLcAhXUFIgKHTpHARQQFggoMAA&url=https%3A%2F%2Fwww.cdc.gov%2F&usg=AOvVaw347QtT6pi6CdNKfM8VFdw6)
* [Taiwan] [Taiwan CDC](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwiHtrL7wYLcAhVBMN4KHfBrAVsQFggnMAA&url=https%3A%2F%2Fwww.cdc.gov.tw%2Frwd%2Fenglish&usg=AOvVaw38J-feE5v9DF9Y0Q2yQcc5) 
* [Thailand] [Thailand CDC](http://203.157.15.110/boe/home.php)
* [Thailand] [Thailand National Disease Surveillance](http://www.boe.moph.go.th/boedb/surdata/)
* [Japan] [Ministry of Health](https://www.mhlw.go.jp/english/)
* [Japan] [Surveillance report- National Institute of Infectious Diseases](http://www.niid.go.jp/niid/en/iasr-e.html)