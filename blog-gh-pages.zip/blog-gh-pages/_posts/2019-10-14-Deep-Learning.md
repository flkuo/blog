---
layout: post
category: Statistics
tagline: 
tags: [R]
---
{% include JB/setup %}


* [Webpage] [深度學習](https://leemeng.tw/deep-learning-for-everyone-understand-neural-net-and-linear-algebra.html)
* [Book] [The Elements of
Statistical Learning:
Data Mining, Inference, and Prediction.
Second Edition](https://web.stanford.edu/~hastie/ElemStatLearn/)
* [Book] **[GraphPad Statistics Guide](https://www.graphpad.com/guides/prism/6/statistics/index.htm?stat_nonparametric_tests_dont_compa.htm)**