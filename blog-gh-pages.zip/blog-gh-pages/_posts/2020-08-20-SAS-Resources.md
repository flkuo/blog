---
layout: post
category: Statistics
tagline: 
tags: [SAS]
---
{% include JB/setup %}


SAS Taiwan

* [SAS Blog](https://blogs.sas.com/content/sastaiwan/)
* [SAS EG Tutorial](https://blogs.sas.com/content/sastaiwan/sas-enterprise-guide/sas-eg-中文教學影片/)
* [SAS official courses- December, 2020](https://sas.webex.com/mw3300/mywebex/default.do?nomenu=true&siteurl=sas-tc&service=6&rnd=0.7853218663293898&main_url=https%3A%2F%2Fsas.webex.com%2Fec3300%2Feventcenter%2Fprogram%2FprogramDetail.do%3FtheAction%3Ddetail%26internalProgramTicket%3D4832534b0000000461afc5bd988613d0d40c3cb18b641a8f8f043bf3e7f22a805a0947b46d85d3bf%26siteurl%3Dsas-tc%26internalProgramTicketUnList%3D4832534b0000000461afc5bd988613d0d40c3cb18b641a8f8f043bf3e7f22a805a0947b46d85d3bf%26cProgViewID%3D1600047%26PRID%3D96e025d385b9138be83dc24bb50fa66c)

SAS International 
