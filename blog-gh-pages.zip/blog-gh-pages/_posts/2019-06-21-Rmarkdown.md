---
layout: post
category: Statistics
tagline: 
tags: [R, Rmarkdown]
---
{% include JB/setup %}

R Markdown


* [Book] [R Markdown](https://bookdown.org/yihui/rmarkdown/) 
* [Webpage] [Presentations with slidy](https://garrettgman.github.io/rmarkdown/slidy_presentation_format.html)
* [Webpage] [Templates for R Markdown](http://jianghao.wang/post/2017-12-08-rmarkdown-templates/)
* **[Webpage] [Revealjs](https://github.com/rstudio/revealjs#display-modes)**
* [Webpage] [Themes](http://www.datadreaming.org/post/r-markdown-theme-gallery/)
* [Webpage] [Tufte Handouts](https://garrettgman.github.io/rmarkdown/tufte_handout_format.html) A template known for its extensive use of sidenotes, tight integration of graphics with text, and well-set typography
* [Webpage] [Tufte Handouts](http://rstudio.github.io/tufte/) 
* [Webpage] [Prettydoc](https://prettydoc.statr.me/)
