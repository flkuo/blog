---
layout: post
category: Statistics
tagline: 
tags: [Analysis]
---
{% include JB/setup %}

This page contains a collection of links related to single case design


* [Book] [Design and Analysis of Single-Case Research.](https://books.google.com/books?hl=en&lr=&id=aKSYAgAAQBAJ&oi=fnd&pg=PP1&dq=design+and+analysis+of+single+case+research&ots=sEqi-Hxw6E&sig=ABhy6SymBA-pRuBWtvDKThuEXTs&redir_esc=y#v=onepage&q=design%20and%20analysis%20of%20single%20case%20research&f=false) Edited by Ronald D. Franklin, David B. Allison, Bernard S. Gorman

* [Book] Single-case research designs: Methods for clinical and applied settings, 2nd ed. [Single-case research designs](http://psycnet.apa.org/record/2010-18971-000)