---
layout: post
category: Statistics
tagline: 
tags: [R]
---
{% include JB/setup %}


* [Webpage] [Web Scraping Product Data in R with rvest and purrr](https://www.r-bloggers.com/web-scraping-product-data-in-r-with-rvest-and-purrr/)
* [Webpage] [PDF Scraping in R with tabulizer](https://www.business-science.io/code-tools/2019/09/23/tabulizer-pdf-scraping.html)
* [Webpage] [Build A R Shiny App (Tutorial) - Wedding Risk Model](https://www.business-science.io/business/2019/06/09/Wedding-Risk-Model-App.html)